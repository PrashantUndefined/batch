# K- Means  Model 
install.packages("animation")
library(animation)   #  To get the visualization of the graph
library(dplyr)
library(ggplot2)

df <- data.frame(age = c(18, 21, 22, 24, 26, 26, 27, 30, 31, 35, 39, 40, 41, 42, 44, 46, 47, 48, 49, 54),
                 spend = c(10, 11, 22, 15, 12, 13, 14, 33, 39, 37, 44, 27, 29, 20, 28, 21, 30, 31, 23, 24)
)
ggplot(df, aes(x = age, y = spend)) +
  geom_point()


myfile  <-  "D:/Users/400221371/Desktop/computer.txt"
mean_data  <- read.table(myfile , header = T , sep = ",")
mean_data  <-  mena_data %>% select(-c(X , cd , multi  , premium))

str(mean_data)
summary(mena_data)
# good practice with k mean and distance calculation is to rescale the data
#so that the mean is equal to one and the standard deviation is equal to zero.


rescale_df <- mean_data %>%  mutate(price_scal = scale(price),
         hd_scal = scale(hd),
         ram_scal = scale(ram),
         screen_scal = scale(screen),
         ads_scal = scale(ads),
         trend_scal = scale(trend)) %>%  select(-c(price, speed, hd, ram, screen, ads, trend))


set.seed(2345)
kmeans.ani(rescale_df[2:3], 3)

pc_cluster <-kmeans(rescale_df, 5)

#Construct a function to compute the total within clusters sum of squares

kmean_withinss <- function(k) {
  cluster <- kmeans(rescale_df, k)
  return (cluster$tot.withinss)
}

kmean_withinss(2)

