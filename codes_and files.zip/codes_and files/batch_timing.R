install.packages("readxl")
install.packages("caret")
install.packages("randomForest")
library(randomForest)
library(caret)
library(readxl)
# Read Data 
# Pre-processing of Data 
# Apply model on the Data 
# Make a Prediction 

batch_data <-  "<file_path>"
Read_Batch_Data  <- read_excel(batch_data , sheet = 1 , col_names = T )


# Make Train and Test Data , 80 / 20

sample <- sample.int(n = nrow(Read_Batch_Data), size = floor(.80*nrow(Read_Batch_Data)), replace = F)
model_sample  <- Read_Batch_Data[sample, ]

# Use  this Data to Predict the model

predict_batch  <- Read_Batch_Data[-sample, ]

# Divide the model data into 70 / 30 to train  and test the data 

second_sample <-  sample.int(n=nrow(model_sample) , size = floor(.70*nrow(model_sample)) , replace = F)

train_batch   <-  model_sample[second_sample ,]
test_batch    <-  model_sample[-second_sample ,]

###############Pre-Processing of Data ######################### 


# Fitting model
fit <- randomForest(<predicted_varible> ~ ., x,ntree=500)
summary(fit)

#Predict Output 
predicted= predict(fit,x_test)

