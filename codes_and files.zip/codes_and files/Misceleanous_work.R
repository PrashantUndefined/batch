m <- matrix(sample(c(NA, 1:10), 100, replace = TRUE), 10)
d <- as.data.frame(m)

d[is.na(d)] <-  0

arr<-c(1,2,4,NA,NA,11,NA,10)
#Now, let's write the function to impute the values:
  missing_mean <- function(arr){
    ifelse(is.na(arr),mean(arr,na.rm = T),arr)
  }

  missing_mean(arr)  
  
  
  melt(arr) 
  
  dcast()
  
  
  tibble()
  
  
  
  fac <- factor(c(2.3, 1.5, 3, 4.9))
as.numeric(fac)  
levels(fac)[fac]



vec <- c(1,3,4,7)
  
  paste(vec,c("#","?"),sep = "-")
  
  
  for (index in 1:3) {
    index <- index * 2
    print(index) 
  }

  
  
  
  
  fac <- factor(letters[1:10])
   levels(fac) #DataFlair
   fac
   as.integer(fac)
   levels(fac) <- rev(levels(fac))
   levels(fac)
   fac
   as.integer(fac)

   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   ## Classification:
   ##data(iris)
   set.seed(71)
   iris.rf <- randomForest(Species ~ ., data=iris, importance=TRUE,
                           proximity=TRUE)
   print(iris.rf)
   ## Look at variable importance:
   round(importance(iris.rf), 2)
   ## Do MDS on 1 - proximity:
   iris.mds <- cmdscale(1 - iris.rf$proximity, eig=TRUE)
   op <- par(pty="s")
   pairs(cbind(iris[,1:4], iris.mds$points), cex=0.6, gap=0,
         col=c("red", "green", "blue")[as.numeric(iris$Species)],
         main="Iris Data: Predictors and MDS of Proximity Based on RandomForest")
   par(op)
   print(iris.mds$GOF)
   
   ## The `unsupervised' case:
   set.seed(17)
   iris.urf <- randomForest(iris[, -5])
   MDSplot(iris.urf, iris$Species)
   
   ## stratified sampling: draw 20, 30, and 20 of the species to grow each tree.
   (iris.rf2 <- randomForest(iris[1:4], iris$Species, 
                             sampsize=c(20, 30, 20)))
   
   ## Regression:
   ## data(airquality)
   set.seed(131)
   ozone.rf <- randomForest(Ozone ~ ., data=airquality, mtry=3,
                            importance=TRUE, na.action=na.omit)
   print(ozone.rf)
   ## Show "importance" of variables: higher value mean more important:
   round(importance(ozone.rf), 2)
   
   ## "x" can be a matrix instead of a data frame:
   set.seed(17)
   x <- matrix(runif(5e2), 100)
   y <- gl(2, 50)
   (myrf <- randomForest(x, y))
   (predict(myrf, x))
   
   ## "complicated" formula:
   (swiss.rf <- randomForest(sqrt(Fertility) ~ . - Catholic + I(Catholic < 50),
                                                                                 data=swiss))
   (predict(swiss.rf, swiss))
   ## Test use of 32-level factor as a predictor:
   set.seed(1)
   x <- data.frame(x1=gl(53, 10), x2=runif(530), y=rnorm(530))
   (rf1 <- randomForest(x[-3], x[[3]], ntree=10))
   
   ## Grow no more than 4 nodes per tree:
   (treesize(randomForest(Species ~ ., data=iris, maxnodes=4, ntree=30)))
   
   ## test proximity in regression
   iris.rrf <- randomForest(iris[-1], iris[[1]], ntree=101, proximity=TRUE, oob.prox=FALSE)
   # str(iris.rrf$proximity)
   
   for(i in 1:9) {
 bc[, i] <- as.numeric(as.character(bc[, i]))
}
 
   
   
   x <-  c(1 , NA , 2 , 4,6 , NA , NA)
   
   new_value  <-  function(x)
   {
     ifelse(is.na(x) , mean(x , na.rm = T) , x)
     
   }
   
   new_value(x)
   
   
   
   
   #class(final_model)
   #final_model <-  as.data.frame(as.matrix(final_model))
   
   
   #predTrain <- predict(final_model[1], train_data_words_df, type = "class")
   
   # Checking the classfication accuracy :: 
   
   #predTrain <-  table(predTrain, train_data_words_df$Category)
   
   # Load the model 
   
   # load the model
   # super_model <- readRDS("D:/model/final_model.rds")
   # print(super_model)
   # # make a predictions on "new data" using the final model
   # final_predictions <- predict(super_model, test_data , type = "class")
   # confusionMatrix(final_predictions, validation$Class)
   # 
   # predict()
   # 
   # # Descion Tree Model
   # #fit_train <- rpart(Category ~., data = train_data_words_df, method = 'class')
   # 
   # predict_fit_train  <- predict(final_model, type = "class")
   # predict_fit_train <- as.factor(predict_fit_train)
   # 
   # #write.xlsx(predict_fit_train , file ="D:/Users/400221371/Desktop/Final_output.xlsx" , sheetName = "Sheet1" , col.names = T , row.names = F) 
   # 
   # 
   # Check for Accuracy
   
   var=as.data.frame(train_data_words_df$Category[train_data_words_df$Category=="Access Management"])
   confusion_mat=confusionMatrix(train_data_words_df$Category, predict_fit_train)
   cnf_matrix=as.data.frame(as.matrix(confusion_mat))
   
   # 
   # saveRDS(final_model, "./final_model.rds")
   
   # later...
   
   
   # Create a Model on Test Data ::
   # 
   # important_words_test_df <-  important_words_test_df[1:993,]
   # 
   # test_data_words_df <- cbind(test_aviation$Category, important_words_test_df)
   # colnames(test_data_words_df)[1] <- "Category"
   # test_data_words_df <-  test_data_words_df %>% filter(!is.na(test_data_words_df$Category))
   # # Descion Tree Model
   # fit_test<- rpart(Category ~., data = test_data_words_df, method = 'class')
   # 
   # 
   # 
   # predict_fit_test  <- predict(fit_test, type = "class")
   # predict_fit_test <- as.factor(predict_fit_test)
   # 
   # # Check for Accuracy 
   # 
   # var=as.data.frame(test_data_words_df$Category[test_data_words_df$Category=="Access Management"])
   # confusion_mat=confusionMatrix(test_data_words_df$Category, predict_fit_train)
   # cnf_matrix=as.data.frame(as.matrix(confusion_mat))
   
   #sum(cnf_matrix[2,])
   
   #sum(predict_fit[1,])
   
   #max(predict_fit[1,])
   #min(predict_fit[1,])
   
   #rpart.plot(fit, extra = 106)
   
   #test_data_words_df <- cbind(test_data_df, important_words_test_df)
   
   # Get rid of the original Text field
   #train_data_words_df$Text <- NULL
   #test_data_words_df$Text <- NULL
   
   
   #log_model <- glm(Sentiment~., data=eval_train_data_df, family=binomial)
   
      
   