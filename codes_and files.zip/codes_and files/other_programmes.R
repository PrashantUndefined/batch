install.packages("stringr")
install.packages("readxl")
install.packages("qdap")
install.packages("textstem") # For Lamentization
library(tm)
library(qdap)
#library(textstem)
library(readxl)
library(stringr)

myfile  <-   "D:/Users/400221371/Desktop/Aviation Tickets.xlsx"
data  <-  read_excel(myfile , sheet = 1)
data_Description <-  as.data.frame(data$Description)

#data <-  lapply(data_Description, list)

Clean_String <- function(string){
  # Lowercase
  temp <- tolower(string)
  # Remove everything that is not a number or letter (may want to keep more 
  # stuff in your actual analyses). 
  temp <- stringr::str_replace_all(temp,"[^a-zA-Z\\s]", " ")
  # Shrink down to just one white space
  temp <- stringr::str_replace_all(temp,"[\\s]+", " ")
  # Split it
  temp <- stringr::str_split(temp, " ")[[1]]
  # Get rid of trailing "" if necessary
  indexes <- which(temp == "")
  if(length(indexes) > 0){
    temp <- temp[-indexes]
  } 
  return(temp)
}

# Run the Loop for Number of Rows


for ( i in 1:nrow(data_Description))
{

  clear_pan <- Clean_String(data_Description$`data$Description`[[1]])
  print(clear_pan)
  
  # Stemming
  
  stem_data <- stemDocument(clear_pan , language = "english")
  
  stem_data <- as.vector(stem_data)
  class(stem_data)
  #dtm <-  DocumentTermMatrix(stem_data)
  
  #dtm   <-  DocumentTermMatrix(stem_data, control = list(wordLengths = c(2, Inf)))
  
  data <- SimpleCorpus((stem_data, control = list(language = "eng"))
                       
  dtm <- DocumentTermMatrix(mydata) 
 
   print(i)


# 
# # Applying stemming on words :
# 
# terms <- clear_pan
# 
# fake_text <- unlist(lapply(terms, function(x) {
#   paste(sample(c(x, sample(DICTIONARY[[1]], sample(1:5, 1)))), collapse=" ")
# }))
# 
# fake_text
# 
# myCorp <- Corpus(VectorSource(fake_text))
# terms2 <- unique(bag_o_words(as.data.frame(myCorp)[[2]]))
# misses <- terms2[is.na(match(terms2, DICTIONARY[[1]]))]
# 
# chars <- nchar(DICTIONARY[[1]])
# 
# replacements <- sapply(misses, function(x, range = 3, max.distance = .2) {
#   x <- stemDocument(x)
#   wchar <- nchar(x)
#   dict <- DICTIONARY[[1]][chars >= (wchar - range) & chars <= (wchar + range)]
#   dict <- dict[agrep(x, dict, max.distance=max.distance)]
#   names(which.min(sapply(dict, qdap:::Ldist, x)))
# })
# 
# replacer <- content_transformer(function(x) { 
#   mgsub(names(replacements), replacements, x, ignore.case = FALSE, fixed = FALSE)
# })
# 
# myCorp <- tm_map(myCorp, replacer)
# inspect(myCorp <- tm_map(myCorp, stemDocument))
# 

# lower_string <- tolower(data_Description[[i]])
#print(lower_string)
# my_string <- "Example STRING, with example numbers (12, 15 and also 10.2)?!"
# ower_string <- tolower(my_string)
# 
# second_string <-tolower( "Wow, two sentences.")
# my_string <- paste(lower_string,second_string,sep = " ")
# 
# my_string_vector <- str_split(my_string, "!")[[1]]

# 
# Clean_String <- function(string){
#   # Lowercase
#   temp <- tolower(string)
#   # Remove everything that is not a number or letter (may want to keep more 
#   # stuff in your actual analyses). 
#   temp <- stringr::str_replace_all(temp,"[^a-zA-Z\\s]", " ")
#   # Shrink down to just one white space
#   temp <- stringr::str_replace_all(temp,"[\\s]+", " ")
#   # Split it
#   temp <- stringr::str_split(temp, " ")[[1]]
#   # Get rid of trailing "" if necessary
#   indexes <- which(temp == "")
#   if(length(indexes) > 0){
#     temp <- temp[-indexes]
#   } 
#   return(temp)
# }













###################################################

# 
# install.packages("tidyverse")
# install.packages("tokenizers")
# library(tidyverse)
# library(tokenizers)
# 
# text <- paste("Now, I understand that because it's an election season",
#               "expectations for what we will achieve this year are low.",
#               "But, Mister Speaker, I appreciate the constructive approach",
#               "that you and other leaders took at the end of last year",
#               "to pass a budget and make tax good permanent for working",
#               "families. So I hope we can work together this year on some",
#               "bipartisan priorities like criminal justice reform and",
#               "helping people who are battling prescription drug abuse",
#               "and heroin abuse. So, who knows, we might surprise the",
#               "cynics again")
# 
# words <- tokenize_words(text) # Breaking a complex sentence in words is  called tokenitailzations
# length(words)
# 
# 
# #words <-  as.array(unlist(words))
# #words <-  as.array(words)
# 
# tab <- table(words[[1]])
# tab <- data_frame(word = names(tab), count = as.numeric(tab))
# # tabs <- as.data.frame(tab)
# # 
# # arrange(tab , desc(count))
# 
# # Stemming : Find out the root words , by cutting the common prefix and suffix
# # lemmatiatizaion  : it goes for the meaning of word , like word like going , gone and went can be written as go
# # Document Term Matrix :  used for check frequecy of word in a documents
# 
# 
# # tokenizier :
# 
# sentences <-  tokenize_sentences(text)
# 
# sentence_words <- tokenize_words(sentences[[1]])
# 
# sapply(sentence_words, length)
# 
# 
# # Applying stemming on words :
# 
# terms <- c("accounts", "account", "accounting", "acounting", "acount", "acounts", "accounnt")
# 
# install.packages("qdap")
# install.packages("tm")
# library(tm)
# library(qdap)
# 
# fake_text <- unlist(lapply(terms, function(x) {
#   paste(sample(c(x, sample(DICTIONARY[[1]], sample(1:5, 1)))), collapse=" ")
# }))
# 
# fake_text
# 
# 
# myCorp <- Corpus(VectorSource(fake_text))
# terms2 <- unique(bag_o_words(as.data.frame(myCorp)[[2]]))
# misses <- terms2[is.na(match(terms2, DICTIONARY[[1]]))]
# 
# chars <- nchar(DICTIONARY[[1]])
# 
# replacements <- sapply(misses, function(x, range = 3, max.distance = .2) {
#   x <- stemDocument(x)
#   wchar <- nchar(x)
#   dict <- DICTIONARY[[1]][chars >= (wchar - range) & chars <= (wchar + range)]
#   dict <- dict[agrep(x, dict, max.distance=max.distance)]
#   names(which.min(sapply(dict, qdap:::Ldist, x)))
# })
# 
# replacer <- content_transformer(function(x) { 
#   mgsub(names(replacements), replacements, x, ignore.case = FALSE, fixed = FALSE)
# })
# 
# myCorp <- tm_map(myCorp, replacer)
# inspect(myCorp <- tm_map(myCorp, stemDocument))
   
   
   
   
   
   install.packages("text2vec")
   install.packages("tokenizers")
   install.packages("readxl")
   library(tokenizers)
   library(readxl)
   library(dplyr)
   library(tm)
   library(text2vec)
   # Read Data 
   
   myfile  <-   "D:/Users/400221371/Desktop/Aviation Tickets.xlsx"
   data  <-  read_excel(myfile , sheet = 1)
   
   # Checking for missing values
   
   data_x1=  filter(data,data$Category!=" ")
   
   # Fucntion to Delete all the puncuation and convert into lower case
   
   Clean_String <- function(string){
     # Lowercase
     temp <- tolower(string)
     # Remove everything that is not a number or letter (may want to keep more 
     # stuff in your actual analyses). 
     temp <- stringr::str_replace_all(temp,"[^a-zA-Z\\s]", " ")
     # Shrink down to just one white space
     temp <- stringr::str_replace_all(temp,"[\\s]+", " ")
     # Split it
     temp <- stringr::str_split(temp, " ")[[1]]
     # Get rid of trailing "" if necessary
     indexes <- which(temp == "")
     if(length(indexes) > 0){
       temp <- temp[-indexes]
     } 
     return(temp)
   }
   
   
   
   clear_pan <-sapply(data_x1$Description,Clean_String)
   
   documents <- Corpus(VectorSource(data_x1$Description))
   documents = tm_map(documents, content_transformer(tolower))
   documents = tm_map(documents, removePunctuation)
   documents = tm_map(documents, removeWords, stopwords("english"))
   documents <- as.data.frame(unlist(documents))
   documents <- documents %>% mutate_if(is.factor,as.character)
   
   documents <- as.data.frame(unlist(documents))
   
   # Stemming 
   
   documents <- documents %>% mutate_if(is.factor,as.character)
   
   stemDoc<-function(doc){
     return(stemDocument(doc , language = "english"))
   }
   
   documents=as.data.frame(sapply(documents,stemDoc))
   
   bag_of_words <- CountVectorizer$new()
   
   result_df <- cbind(df$id, bag_of_words$fit_transform(df$words))
   
   ################################################################################
   
   corpus <- Corpus(VectorSource(c(data_x1$Description)))
   
   corpus[1]$content
   
   corpus <- tm_map(corpus, content_transformer(tolower))
   # the following line may or may not be needed, depending on
   # your tm  package version
   # corpus <- tm_map(corpus, PlainTextDocument)
   corpus <- tm_map(corpus, removePunctuation)
   corpus <- tm_map(corpus, removeWords, stopwords("english"))
   corpus <- tm_map(corpus, stripWhitespace)
   corpus <- tm_map(corpus, stemDocument)
   corpus <- tm_map(corpus, removeNumbers)
   
   dtm <- DocumentTermMatrix(corpus)
   dtm
   
   
   sparse <- removeSparseTerms(dtm, 0.99)
   sparse
   
   
   important_words_df <- as.data.frame(as.matrix(sparse))
   colnames(important_words_df) <- make.names(colnames(important_words_df))
   # split into train and test
   important_words_train_df <- head(important_words_df, nrow(data_x1))
   important_words_test_df <- tail(important_words_df, nrow(test_data_df))
   
   # Add to original dataframes
   train_data_words_df <- cbind(data_x1, important_words_train_df)
   test_data_words_df <- cbind(test_data_df, important_words_test_df)
   
   # Get rid of the original Text field
   train_data_words_df$Text <- NULL
   test_data_words_df$Text <- NULL
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   # Clean_String <- function(string){
   #   # Lowercase
   #   temp <- tolower(string)
   #   # Remove everything that is not a number or letter (may want to keep more 
   #   # stuff in your actual analyses). 
   #   temp <- stringr::str_replace_all(temp,"[^a-zA-Z\\s]", " ")
   #   # Shrink down to just one white space
   #   temp <- stringr::str_replace_all(temp,"[\\s]+", " ")
   #   # Split it
   #   temp <- stringr::str_split(temp, " ")[[1]]
   #   # Get rid of trailing "" if necessary
   #   indexes <- which(temp == "")
   #   if(length(indexes) > 0){
   #     temp <- temp[-indexes]
   #   } 
   #   return(temp)
   # }
   # 
   # data_x1_Description <-  as.data.frame(data_x1$Description)
   # 
   # for ( i in 1:nrow(data_Description))
   # {
   #   
   #   clear_pan <- Clean_String(data_x1_Description$`data_x1$Description`[[i]])
   #   print(clear_pan)
   #   
   #   # Stemming
   #   
   #  # stem_data <- stemDocument(clear_pan , language = "english")
   #  # print(stem_data)
   #   
   # 
   # }
   # 
   
