# KNN Model 
install.packages("class")
install.packages("gmodels")
library(gmodels)
library(class)

data_model <- mtcars

model_train <-  data_model[1:25,]
model_test <-  data_model[26:32 , ]

model_train_label <-  as.vector(model_train[,8])

model_test_label <-  as.vector(model_test[,8])


#knn fucntion for the KNN model  
# We are finding the value of K , by taking the square root of total number of observation

prc_test_pred <- knn(train = model_train, test = model_test , cl = model_train_label, k=5)

CrossTable(x= model_test_label , y= prc_test_pred , prop.chisq = F)  
