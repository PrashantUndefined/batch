# Logistics Regression Model :

file_path  <-  "D:/Users/400221371/Desktop/african_crises.csv"
data_crises <-  read.csv(file_path , header = T , sep = ",")

data_crises <-  data_crises %>% mutate(banking_crisis = factor(banking_crisis , levels = c ("crisis" , "no_crisis") , labels = c( 'yes' ,'no' )))


sample <- sample.int(n = nrow(data_crises), size = floor(.80*nrow(data_crises)), replace = F)

crisis_train_data <- data_crises[sample, ]

# To Test the Data in the final ouput 

crisistest_data  <- data_crises[-sample, ]

logitmod  <-  glm(banking_crisis~ inflation_annual_cpi , family = "binomial" , data = crisis_train_data)


summary(logitmod)
predict_data <-  predict(logitmod , crisistest_data , type = "response" )


predict_data <-  as.data.frame(predict_data)
