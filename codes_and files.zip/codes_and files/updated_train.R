#Part 1 Training the model


train_model <- defmacro(input_file, save_rds_path ,
                        expr = {
                          
                    

  #  install.packages("readxl")
  # install.packages("caret")
  # install.packages("purr")
  # install.packages("tidyverse")
  # install.packages("dplyr")
  # install.packages("randomForest")
  # install.packages("devtools")
  # install.packages("utf8")
  #install.packages("dummies")  To create a dummy variables for the Feed  Column
  #install.packages("caTools")
  #install.packages("ggplot")
  
  library(gtools)
  library(caTools)
  library(dummies)
  library(utf8)
  library(devtools)
  library(tidyverse)
  library(dplyr)
  library(readxl)
  library(caret)
  
  
  #file_path <-  "D:/Users/400221371/Desktop/ML Files/updated/Ml Data Prepartion.xlsx" # Need to give the file of the Path for Training the Data 
  file_path <- input_file
  
  model_data <-  read_excel(file_path , sheet = 1 , col_names = T)
  model_data <-  model_data
  colnames(model_data)[2] <-  "Current_Time"
  colnames(model_data)[3] <-  "Remaining_Rec"
  colnames(model_data)[4] <-  "Time_Taken_to_Complete_in_minutes"
  
  ###############Pre-Processing of Data ######################### 
  
  model_data$Current_Time <-  substr(model_data$Current_Time , 11, 19)
  
  model_data$Remaining_Rec <-  as.numeric(gsub("k" , replacement = "000" , model_data$Remaining_Rec , ignore.case = T))
  
  # One Hot Encodeing 
  
  #model_train_data <- cbind( model_data)
  
  feed_train_batch <-  dummy(model_data$Feed)
  feed_train_batch <- as.data.frame(feed_train_batch)
  for (i in 1:ncol(feed_train_batch))
  {
    colnames(feed_train_batch)[[i]]  <-  gsub(" " , replacement = "_" ,colnames(feed_train_batch)[[i]] , ignore.case = T)
    colnames(feed_train_batch)[[i]]  <-  gsub(".*xlsx" , replacement = "Feed_" ,colnames(feed_train_batch)[[i]] , ignore.case = T)
    colnames(feed_train_batch)[[i]]  <-  gsub(".*csv" , replacement = "Feed_" ,colnames(feed_train_batch)[[i]] , ignore.case = T)
    #colnames(feed_train_batch)[[i]]  <-  gsub("1" , replacement = "One" ,colnames(feed_train_batch)[[i]] , ignore.case = T)
  }
  

   day <-  dummy(model_data$day)
   day <- as.data.frame(day)
   for (i in 1:ncol(day))
   {
     colnames(day)[[i]]  <-  gsub(" " , replacement = "_" ,colnames(day)[[i]] , ignore.case = T)
     colnames(day)[[i]]  <-  gsub(".*xlsx" , replacement = "day_" ,colnames(day)[[i]] , ignore.case = T)
     colnames(day)[[i]]  <-  gsub(".*csv" , replacement = "day_" ,colnames(day)[[i]] , ignore.case = T)
     #colnames(feed_train_batch)[[i]]  <-  gsub("1" , replacement = "One" ,colnames(feed_train_batch)[[i]] , ignore.case = T)
   }


  current_time_train_batch <-  dummy(model_data$Current_Time )
  current_time_train_batch <- as.data.frame(current_time_train_batch)
  for (i in 1:ncol(current_time_train_batch))
  {
    colnames(current_time_train_batch)[[i]]  <-  gsub(".*xlsx" , replacement = "Current_Time_" ,colnames(current_time_train_batch)[[i]] , ignore.case = T)
    colnames(current_time_train_batch)[[i]]  <-  gsub(".*csv" , replacement = "Current_Time_" ,colnames(current_time_train_batch)[[i]] , ignore.case = T)
     colnames(current_time_train_batch)[[i]]  <-  gsub(" " , replacement = "" ,colnames(current_time_train_batch)[[i]] , ignore.case = T)
    
  }
  
  
  
  
  #final_train_data  <- cbind(model_data$Time_Taken_to_Complete_in_minutes ,model_data$Remaining_Rec  ,feed_train_batch , current_time_train_batch)
  final_train_data  <- cbind(model_data$Time_Taken_to_Complete_in_minutes ,model_data$Remaining_Rec  ,  day ,feed_train_batch , current_time_train_batch)
  colnames(final_train_data)[1] <-   "Time_Taken_to_Complete_in_minutes"
  colnames(final_train_data)[2] <-  "Remaining_Rec"
  
  
 # drops <- c("Feed_1Cal" ,"Current_Time_00:00:00"  )
  drops <- c("Feed_1Cal" ,"Current_Time_00:00:00" , "day_Friday" )
  final_train_data <- final_train_data[ , !(names(final_train_data) %in% drops)]
  
  #### Linear Regression Model #######
  
  linear <- lm(final_train_data$Time_Taken_to_Complete_in_minutes ~ . , data = final_train_data[,-1])
  summary(linear)
  
  

  
  # Save the Model 
  
  saveRDS(linear , file = save_rds_path) # Need To give the location to Save the Model 
  #saveRDS(linear , file = "D:/POC/Data Visualization POC/linear_test.rds")

                        })



train_model("D:/Users/400221371/Desktop/ML Files/updated/Ml Data Prepartion.xlsx", paste0("D:/model/linear_test_day","_" ,Sys.Date() , ".rds"))



