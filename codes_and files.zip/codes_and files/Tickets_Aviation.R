 source("D:/Users/400221371/Desktop/train_function.R")
#install.packages("xlsx")
library(xlsx)

myfile  <-   "D:/Users/400221371/Desktop/Aviation Tickets_new.xlsx"
data_aviation  <-  read.xlsx(myfile , sheetName = 1)
data_aviation<-data_aviation %>% filter(!is.na(data_aviation$Category))

# Make Train and Test Data , 80 / 20

sample <- sample.int(n = nrow(data_aviation), size = floor(.80*nrow(data_aviation)), replace = F)
train_aviation <- data_aviation[sample, ]

# To Test the Data in the final ouput 

test_aviation  <- data_aviation[-sample, ]

# Train and test model for model aviation  

# new_sample <-  sample.int(n = nrow(model_aviation) , size = floor(.80 * nrow(model_aviation)) , replace = F)
# train_data <-  model_aviation[new_sample ,]
# #train_data <-  train_data %>% filter(!is.na(train_data$Category))
# 
# test_data  <-  model_aviation[-new_sample ,]


random_data(train_aviation)
#colnames(train_data_words_df)[2] <- "Description"
#train_data_words_df <-   train_data_words_df[,-2]
#train_data_words_df <-  train_data_words_df %>% filter(!is.na(train_data_words_df$Category))

#}
#final_data  <-  cbind(train_data , main_words_train_df)
#random_data(train_data)

# Random Forest Model  :
#train_data_words_df <-  train_data_words_df[1:500 ,]
final_model <- randomForest(Category~., final_data_words_df, mtry=2, ntree=2000)
#final_model <-  rpart(Category~., train_data_words_df , method = "class")

#final_model <- randomForest(Category~., train_data_words_df, importance = TRUE)

predict_Train  <-  predict(final_model ,  train_aviation , type = "class" )

predict_Train <- as.data.frame(predict_Train)

predicted_values <-  cbind(train_data , predict_Train)

train_var <-  na.omit(as.data.frame(train_data$Category))
#confusionMatrix(data = predict_Train$predict_Train , reference = train_data$Category , positive = "yes")
#sum(is.na(train_data$Category))
table_train  <-  table(predict_Train , train_data$Category)

train_confusion <-  unlist(as.matrix(table_train))

# Creata Heat Map 

ncol(train_confusion)
z <-  matrix(train_confusion, ncol=61)
image(z[,ncol(z):1], axes=FALSE)

axis(2, at = seq(0, 1, length=length(colnames(train_confusion))), labels=colnames(train_confusion))
heatmap(t(z)[ncol(z):1,], Rowv=NA, Colv=NA, col = heat.colors(256))

# Run the Model on Test Data :

final_model <- randomForest(Category~., test_data , importance = TRUE)

predict_Train  <-  predict(final_model , test_data ,  type = "class")

# Save the Model 

saveRDS(final_model , file = "D:/model/final_model.rds")

# load the model
super_model <- readRDS("D:/model/final_model.rds")
#class(super_model)
print(super_model)
# make a predictions on "new data" using the final model
final_predictions <- predict(super_model , test_data  , type = "response")

confusionMatrix(final_predictions,test_aviation$Category)
