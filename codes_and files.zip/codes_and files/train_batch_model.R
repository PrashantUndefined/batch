#  install.packages("readxl")
# install.packages("caret")
# install.packages("purr")
# install.packages("tidyversev")
# install.packages("dplyr")
# install.packages("randomForest")
# install.packages("devtools")
# install.packages("utf8")
#install.packages("dummies")  To create a dummy variables for the Feed  Column
#install.packages("caTools")
#install.packages("ggplot")
library(ggplot2)
library(caTools)
library(dummies)
library(utf8)
library(devtools)
library(tidyverse)
library(dplyr)
library(randomForest)
library(readxl)
library(caret)

file_path <-  "D:/Users/400221371/Desktop/ML Files/updated/Ml Data Prepartion.xlsx"

batch_data <-  read_excel(file_path , sheet = 1 , col_names = T)

colnames(batch_data)[2] <-  "Current_Time"
colnames(batch_data)[3] <-  "Remaining_Rec"
colnames(batch_data)[4] <-  "Time_Taken_to_Complete_in_minutes"
# Make Train and Test Data , 80 / 20

sample <- sample.int(n = nrow(batch_data), size = floor(.70*nrow(batch_data)), replace = F)
model_train_data   <- batch_data[sample, ]
model_data  <-  model_train_data

# Use  this Data to Predict the model

predict_batch_data   <- batch_data[-sample, ]

# Data Write with Time Column
write.csv(model_data , file =  "D:/Users/400221371/Desktop/ML Files/updated/train_data_70.csv" , row.names = F )
write.csv(predict_batch_data , file =  "D:/Users/400221371/Desktop/ML Files/updated/test_data_30.csv" , row.names = F )

# Data write without Time column 
predict_batch_data <-  predict_batch_data[ ,-4]

write.csv(predict_batch_data , file =  "D:/Users/400221371/Desktop/test_data_feed.csv" , row.names = F )

###############Pre-Processing of Data ######################### 

model_data$Current_Time<-  substr(model_data$Current_Time , 11, 19)

model_data$Remaining_Rec <-  as.numeric(gsub("k" , replacement = "000" , model_data$Remaining_Rec , ignore.case = T))

# One Hot Encodeing 

#model_train_data <- cbind( model_data)

feed_train_batch <-  dummy(model_data$Feed)
feed_train_batch <- as.data.frame(feed_train_batch)

current_time_train_batch <-  dummy(model_data$Current_Time )
current_time_train_batch <- as.data.frame(current_time_train_batch)


final_train_data  <-cbind( model_data$Time_Taken_to_Complete_in_minutes ,model_data$Remaining_Rec  ,  feed_train_batch , current_time_train_batch)
colnames(final_train_data)[1] <-   "Time_Taken_to_Complete_in_minutes"
colnames(final_train_data)[2] <-  "Remaining_Rec"

drops <- c("Feed1 Ingestion End time" ,"Current_Time 00:00:00")
final_train_data <- final_train_data[ , !(names(final_train_data) %in% drops)]


#### Linear Regression Model #######

linear <- lm(final_train_data$Time_Taken_to_Complete_in_minutes ~ . , data = final_train_data)
summary(linear)


# Save the Model 

saveRDS(linear , file = "D:/model/linear.rds")



# Box Plot Check for outliers 

par(mfrow=c(1, 2))  # divide graph area in 2 columns

boxplot(final_train_data$`Remaining Rec`, main="Remaining Rec", sub=paste("Outlier rows: ", boxplot.stats(final_train_data$`Remaining Rec`)$out))  # box plot for 'Remaining Record'

boxplot(final_train_data$`Time Taken to Complete(in minutes)`, main="Time Taken to Complete(in minutes)",
        sub=paste("Outlier rows: ", boxplot.stats(final_train_data$`Time Taken to Complete(in minutes)`)$out)) # box plot for 'Time Taken to Complete(in minutes)'

#Density plot - Check if the response variable is close to normality

par(mfrow=c(1, 2))  # divide graph area in 2 columns
plot(density(final_train_data$`Remaining Rec`), main="Density Plot: `Remaining Rec`", ylab="Frequency", sub=paste("Skewness:", round(e1071::skewness(final_train_data$`Remaining Rec`), 2)))  # density plot for '`Remaining Rec`'

polygon(density(final_train_data$`Remaining Rec`), col="red")

plot(density(final_train_data$`Time Taken to Complete(in minutes)`), main="Density Plot: `Time Taken to Complete(in minutes)`", ylab="Frequency", sub=paste("Skewness:", round(e1071::skewness(final_train_data$`Time Taken to Complete(in minutes)`), 2)))  # density plot for '`Time Taken to Complete(in minutes)`'
polygon(density(final_train_data$`Time Taken to Complete(in minutes)`), col="red")


