#  install.packages("readxl")
# install.packages("caret")
# install.packages("purr")
# install.packages("tidyversev")
# install.packages("dplyr")
# install.packages("randomForest")
# install.packages("devtools")
# install.packages("utf8")
#install.packages("dummies")  To create a dummy variables for the Feed  Column
#install.packages("caTools")
#install.packages("ggplot")
library(ggplot2)
library(caTools)
library(dummies)
library(utf8)
library(devtools)
library(tidyverse)
library(dplyr)
library(randomForest)
library(readxl)
library(caret)

file_path <-  "D:/Users/400221371/Desktop/MLData Prepartion.xlsx"
  
batch_data <-  read_excel(file_path , sheet = 1 , col_names = T)

#batch_data <-  batch_data[,-c(5:10)]

# Make Train and Test Data , 80 / 20

sample <- sample.int(n = nrow(batch_data), size = floor(.80*nrow(batch_data)), replace = F)
model_sample  <- batch_data[sample, ]

### To Do's

# Write into Csv
# model predict  - 
# model test - all columns
# 

# Use  this Data to Predict the model

predict_batch_data   <- batch_data[-sample, ]

# Divide the model data into 70 / 30 to train  and test the data 
set.seed(123)
second_sample <-  sample.int(n=nrow(model_sample) , size = floor(.70*nrow(model_sample)) , replace = F)
set.seed(123)
train_batch   <-  model_sample[second_sample ,]
test_batch    <-  model_sample[-second_sample ,]

###############Pre-Processing of Data ######################### 

train_batch$`Current Time`<-  substr(train_batch$`Current Time` , 11, 19)

train_batch$`Remaining Rec` <-  as.numeric(gsub("k" , replacement = "000" , train_batch$`Remaining Rec` , ignore.case = T))

# data.write <- data.frame() # Created Blank Data Frame to write the new values
# 
# for(i in 1:nrow(train_batch))
# { 
#   
# if (substr(train_batch$`Remaining Rec`[[i]] ,1,1) == ">")
# {
#   clean_data <-  trimws(gsub(">" , replacement = "" , train_batch$`Remaining Rec`[[i]] , ignore.case = T))
#   clean_data  <-  as.numeric(clean_data) + 50000
#   
# }
#   else
#   {
#     
#      clean_data  <-  str_split_fixed(train_batch$`Remaining Rec`[[i]] , "-" , 2)
#      clean_data <- as.numeric(clean_data[,2])  # Get maximum Range
#      #min_range <-  clean_data[,1] # Get Minimum range
#     
#   }
#       
#    new_data  <- data.frame(Remaining_Rec =  clean_data )   
#    data.write <-  rbind(data.write , new_data)
#    
# }
# 
# Delete the old Remaining Rec Column and bind the new Column 
#train_batch <-  train_batch[,-3]
#train_batch <- cbind(train_batch, data.write )


# One Hot Encodeing 

feed_train_batch <- cbind(train_batch , dummy(train_batch$Feed, sep = "_"))
feed_train_batch <-  feed_train_batch [, -5]
feed_train_batch <-  feed_train_batch[,-c(1:2)]

current_time_train_batch <- cbind(train_batch  , dummy(train_batch$`Current Time` , sep = "_"))
current_time_train_batch <-  current_time_train_batch [, -5]
current_time_train_batch <-  current_time_train_batch [ ,-c(1:4)]

#unique(train_batch_current_time$`Current Time`)
final_train_data  <-  cbind(feed_train_batch[,c(1:2)] , current_time_train_batch)
colnames(final_train_data)

final_train_data  <-  cbind(feed_train_batch)

# Correleation 
cor(final_train_data$`Remaining Rec`,final_train_data$`Time Taken to Complete(in minutes)`)

#Final Train
#final_train_data <-  final_train_data[ ,-c(1:2)]
sum(is.na(final_train_data))


#str(final_train_data)

#cor( final_train_data$train_batch_1cal_paymt, final_train_data$`Time Taken to Complete(in minutes)`)

set.seed(123)   

sample = sample.split(final_train_data,SplitRatio = 0.80) 

train1 =subset(final_train_data,sample ==TRUE)
test1 =subset(final_train_data, sample==FALSE)

set.seed(123)
# Split the data in 70 and 30 Ratio 

sample_new <-  sample.split(train1 , SplitRatio = 0.70)
new_train_data  <-  subset(train1 , sample == TRUE)
new_test_data  <-  subset(train1 , sample == FALSE)


y_train <-  new_train_data$`Time Taken to Complete(in minutes)`
#x_train <-  new_train_data[,-c(1:2)]

y_test <-  new_test_data$`Time Taken to Complete(in minutes)`
y_test <- as.data.frame(y_test)
#### Linear Regression Model #######

linear <- lm(new_train_data$`Time Taken to Complete(in minutes)` ~ . , data = new_train_data)
summary(linear)
plot(linear$fitted.values,linear$residuals)


#Poisson
poisson.model <- glm(new_train_data$`Time Taken to Complete(in minutes)` ~ ., data = new_train_data, family = poisson(link = "log"))
summary(poisson.model)


#colnames(new_train_data[,-2])
# Prediction on Test Data 

predicted <-  predict(linear,new_test_data[,-2])

# In Confusion Matrix  , predicted values is not taking as Data Frame
predicted <- as.data.frame(predicted)  

combined_data  <- cbind(predicted , y_test)
write.csv(combined_data , file = "D:/Users/400221371/Desktop/data_compare_full.csv" , row.names = F )

ceiling_dec <- function(x, level=1) round(x + 5*10^(-level-1), level)

pre_min  <- ceiling_dec(min(predicted) ,2)

pre_max <-  ceiling_dec(max(predicted),2)

act_min  <-  ceiling_dec(min(new_test_data$`Time Taken to Complete(in minutes)` ,2))
act_max <-  ceiling_dec(max(new_test_data$`Time Taken to Complete(in minutes)` ,2))

matrix <-  confusionMatrix(factor(predicted, levels=pre_min:act_max), factor(new_test_data$`Time Taken to Complete(in minutes)`, levels=pre_min:act_max))


#confusionMatrix(predicted,new_test_data$`Time Taken to Complete(in minutes)`)
##### Random Forest Model  ############
# 
# fit <- randomForest(y_train ~. , new_train_data , mtry= 2 ,ntree=500)
# summary(fit)

#Predict Output 

#predicted= predict(fit,new_test_data)

#
