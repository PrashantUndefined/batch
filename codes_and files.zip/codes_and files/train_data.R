#  install.packages("readxl")
# install.packages("caret")
# install.packages("purr")
# install.packages("tidyversev")
# install.packages("dplyr")
# install.packages("randomForest")
# install.packages("devtools")
# install.packages("utf8")
#install.packages("dummies")  To create a dummy variables for the Feed  Column
#install.packages("caTools")
#install.packages("ggplot")
install.packages("Rserve")

train_data  <- defmacro(train_csv_file ,  model_save_path , 
                        
                       expr = {
                          

library(Rserve)   
Rserve()
library(caTools)
library(dummies)
library(utf8)
library(devtools)
library(tidyverse)
library(dplyr)
library(readxl)
library(caret)
library(gtools)                        
                         
                         
                         


file_path <-  train_csv_file

model_data <-  read_excel(file_path , sheet = 1 , col_names = T)

colnames(model_data)[2] <-  "Current_Time"
colnames(model_data)[3] <-  "Remaining_Rec"
colnames(model_data)[4] <-  "Time_Taken_to_Complete_in_minutes"

###############Pre-Processing of Data ######################### 

model_data$Current_Time <-  substr(model_data$Current_Time , 11, 19)

model_data$Remaining_Rec <-  as.numeric(gsub("k" , replacement = "000" , model_data$Remaining_Rec , ignore.case = T))

# One Hot Encodeing 

#model_train_data <- cbind( model_data)

feed_train_batch <-  dummy(model_data$Feed)
feed_train_batch <- as.data.frame(feed_train_batch)

current_time_train_batch <-  dummy(model_data$Current_Time )
current_time_train_batch <- as.data.frame(current_time_train_batch)


final_train_data  <- cbind(model_data$Time_Taken_to_Complete_in_minutes ,model_data$Remaining_Rec  ,  feed_train_batch , current_time_train_batch)
colnames(final_train_data)[1] <-   "Time_Taken_to_Complete_in_minutes"
colnames(final_train_data)[2] <-  "Remaining_Rec"


for (i in 1:ncol(final_train_data))

{
  colnames(final_train_data)[[i]]  <-  gsub(" " , replacement = "_" ,colnames(final_train_data)[[i]] , ignore.case = T)
  colnames(final_train_data)[[i]]  <-  gsub(":" , replacement = "_" ,colnames(final_train_data)[[i]] , ignore.case = T) 
}

drops <- c("Feed1Cal" ,"Current_Time_00_00_00")
final_train_data <- final_train_data[ , !(names(final_train_data) %in% drops)]

#### Linear Regression Model #######

linear <- lm(final_train_data$Time_Taken_to_Complete_in_minutes ~ . , data = final_train_data)
summary(linear)


# Save the Model 

  saveRDS(linear , file = model_save_path)
  

                        })


train_data( "D:/Users/400221371/Desktop/MLData Prepartion.xlsx", paste0("D:/model/linear_test","_" ,Sys.Date() , ".rds"))

scatter.smooth(x=final_train_data$Remaining_Rec, y=final_train_data$Time_Taken_to_Complete_in_minutes, main="Time_Taken_to_Complete_in_minutes ~ Remaining_Rec")
