# Descion Tree  Implementation
# Steps of Implementaing Descion Tree Model  

# Step 1: Import the data
# Step 2: Clean the dataset
# Step 3: Create train/test set
# Step 4: Build the model
# Step 5: Make prediction
# Step 6: Measure performance
# Step 7: Tune the hyper-parameters

#install.packages("rpart.plot")
library(rpart.plot)
library(readxl)

myfile1  <-   "D:/Users/400221371/Desktop/titanic_movie.csv"
data <- read.csv(myfile1 , header=  TRUE)
head(data)
tail(data)

# From head and taul , we can see that data is not suffled  , so this will create a issue

shuffle_index <- sample(1:nrow(data))
head(shuffle_index)

data <- data[shuffle_index, ]
head(data)

data <- data %>% replace(.=="NULL", NA)
# Clean the Data Set 

#install.packages("dplyr")
library(dplyr)

clean_titanic <- data %>% select(-c(home.dest, cabin, name,  ticket)) %>% 

  #Convert to factor level
  
  mutate(pclass = factor(pclass, levels = c(1, 2, 3), labels = c('Upper', 'Middle', 'Lower')),
         survived = factor(survived, levels = c(0, 1), labels = c('No', 'Yes'))) 

glimpse(clean_titanic)

# Create  Train and Test Data set 
# Install rpart.plot to  create a train and test data sets


sample <- sample.int(n = nrow(clean_titanic), size = floor(.80*nrow(clean_titanic)), replace = F)
train <- clean_titanic[sample, ]
test  <- clean_titanic[-sample, ]


prop.table(table(train$survived))

prop.table(table(test$survived))


dim(train)
dim(test)



library(rpart)
library(rpart.plot)

# On train Data 
fit <- rpart(sex ~., data = train, method = 'class')
rpart.plot(fit, extra = 106)

# Test Data

fit_test <- rpart(survived ~., data = test, method = 'class')
rpart.plot(fit_test, extra = 106)

# Automatically select a value based on the model type, as follows:
# extra=106 class model with a binary response
# extra=104 class model with a response having more than two levels
# extra=100 other models

# Prediction  on Test Data

predict_unseen <-predict(fit_test, test, type = 'class')


table_mat <- table( test$sex, predict_unseen)









# train_data <-  sample(1:nrow(clean_titanic) , 0.8 * nrow(clean_titanic))
# 
# dim(train_data)
# 
# test_data <-  setdiff(1:nrow(clean_titanic), train_data)
# 
# prop.table(table(train_data$survived))
# 
# create_train_test & lt;- function(data_set, size = 0.8, train = TRUE) {
#   n_row = nrow(clean_titanic)
#   total_row = 0.8 * n_row
#   train_sample & lt; - 1: total_row
#   if (train == TRUE) {
#     return (data_set[train_sample, ])
#   } else {
#     return (data_set[-train_sample, ])
#   }
# }
# 
 