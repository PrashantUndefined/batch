
#Part2 Predicting the output


predict_data <- defmacro(save_prediction, saved_rds , expr = {
  

  #  install.packages("readxl")
  # install.packages("caret")
  # install.packages("purr")
  # install.packages("tidyversev")
  # install.packages("dplyr")
  # install.packages("randomForest")
  # install.packages("devtools")
  # install.packages("utf8")
  #install.packages("dummies")  To create a dummy variables for the Feed  Column
  #install.packages("caTools")
  #install.packages("ggplot")
  #install.packages("gtools")
  
  
  
  library(ggplot2)
  library(caTools)
  library(dummies)
  library(utf8)
  library(devtools)
  library(tidyverse)
  library(dplyr)
  library(readxl)
  library(caret)
  
  predicted_file_data  <- save_prediction
  #predicted_file_data  <- "D:/Users/400221371/Desktop/ML Files/updated/test_data_30.csv" # please provide the path for the file for prediction
  #read_test_data <-  read.csv( predicted_file_data   , header = T)
  read_test_data <-  read_excel(predicted_file_data , sheet = 1 , col_names = T)
  
  pred_data <-  read_test_data
  colnames(pred_data)[2] <-  "Current_Time"
  colnames(pred_data)[3] <-  "Remaining_Rec"
  
  
  pred_data$Current_Time  <-  substr(pred_data$Current_Time , 11, 19)
  
  pred_data$Remaining_Rec <-  as.numeric(gsub("k" , replacement = "000" , pred_data$Remaining_Rec , ignore.case = T))
  
  # One Hot Encodeing 
  
  #model_train_data <- cbind( pred_data)
  
  feed_pred_batch <-  dummy(pred_data$Feed)
  feed_pred_batch <- as.data.frame(feed_pred_batch)
  for (i in 1:ncol(feed_pred_batch))
    
  {
    colnames(feed_pred_batch)[[i]]  <-  gsub(" " , replacement = "_" ,colnames(feed_pred_batch)[[i]] , ignore.case = T)
    colnames(feed_pred_batch)[[i]]  <-  gsub(".*csv" , replacement = "Feed_" ,colnames(feed_pred_batch)[[i]] , ignore.case = T)
    colnames(feed_pred_batch)[[i]]  <-  gsub(".*xlsx" , replacement = "Feed_" ,colnames(feed_pred_batch)[[i]] , ignore.case = T)
    #colnames(feed_pred_batch)[[i]]  <-  gsub("1" , replacement = "One" ,colnames(feed_pred_batch)[[i]] , ignore.case = T)
    
  }
  
  day <-  dummy(pred_data$day)
  day <- as.data.frame(day)
  for (i in 1:ncol(day))
  {
    colnames(day)[[i]]  <-  gsub(" " , replacement = "_" ,colnames(day)[[i]] , ignore.case = T)
    colnames(day)[[i]]  <-  gsub(".*csv" , replacement = "day_" ,colnames(day)[[i]] , ignore.case = T)
    colnames(day)[[i]]  <-  gsub(".*xlsx" , replacement = "day_" ,colnames(day)[[i]] , ignore.case = T)
    #colnames(feed_train_batch)[[i]]  <-  gsub("1" , replacement = "One" ,colnames(feed_train_batch)[[i]] , ignore.case = T)
  }

  
  
  current_time_pred_batch <-  dummy(pred_data$Current_Time )
  current_time_pred_batch <- as.data.frame(current_time_pred_batch)
  for (i in 1:ncol(current_time_pred_batch))
    
  {
    colnames(current_time_pred_batch)[[i]]  <-  gsub(".*csv" , replacement = "Current_Time_" ,colnames(current_time_pred_batch)[[i]] , ignore.case = T)
    colnames(current_time_pred_batch)[[i]]  <-  gsub(".*xlsx" , replacement = "Current_Time_" ,colnames(current_time_pred_batch)[[i]] , ignore.case = T) 
    colnames(current_time_pred_batch)[[i]]  <-  gsub(" " , replacement = "" ,colnames(current_time_pred_batch)[[i]] , ignore.case = T) 
  }
  
  final_pred_data  <- cbind( Remaining_Rec=pred_data$Remaining_Rec  , day,  feed_pred_batch , current_time_pred_batch)
  
  drops <- c("Feed_1Cal" ,"Current_Time_00:00:00" , "day_Friday"   )
  final_pred_data <- final_pred_data[ , !(names(final_pred_data) %in% drops)]
  
  final_pred_data$
  
  # load the model
  #linear <- readRDS("D:/POC/Data Visualization POC/linear_test1.rds") # Need to provide the path , where the train model saved
  linear_test <- readRDS("D:/model/linear_test_day_2020-01-24.rds")
  summary(linear_test)
  
  
  # make a predictions on "new data" using the final model
  
  final_predictions <- predict(linear_test , final_pred_data)
  
  
  final_predictions_day <-  as.data.frame(final_predictions)
  
  output  <-  cbind(pred_data , final_predictions_day  )
  
  output_path  <-  "D:/Users/400221371/Desktop/ML Files/updated/predicted_day_23.csv" # path where you want the final output 
  
  write.csv(output , file = output_path  , row.names = F )
  
  
})


predict_data("D:/Users/400221371/Desktop/ML Files/updated/Ml Data Prepartion.xlsx", "D:/model/linear_test_day_2020-01-24.rds")


