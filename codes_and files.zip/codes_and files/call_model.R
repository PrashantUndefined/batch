
# load the model
super_model <- readRDS("D:/model/final_model.rds")
class(super_model)
print(super_model)
# make a predictions on "new data" using the final model
final_predictions <- predict(super_model , test_data  , type = "response")

confusionMatrix(final_predictions,test_aviation$Category)

dim(test_aviation)



