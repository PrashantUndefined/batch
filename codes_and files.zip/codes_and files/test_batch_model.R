# Test the 20% of the Data Through Saved Model


read_test_data <-  read.csv("D:/Users/400221371/Desktop/test_data_feed.csv")

model_data <-  read_test_data
colnames(model_data)[2] <-  "Current_Time"
colnames(model_data)[3] <-  "Remaining_Rec"


model_data$Current_Time<-  substr(model_data$Current_Time , 11, 19)

model_data$Remaining_Rec <-  as.numeric(gsub("k" , replacement = "000" , model_data$Remaining_Rec , ignore.case = T))

# One Hot Encodeing 

#model_train_data <- cbind( model_data)

feed_pred_batch <-  dummy(model_data$Feed)
feed_pred_batch <- as.data.frame(feed_pred_batch)

current_time_pred_batch <-  dummy(model_data$Current_Time )
current_time_pred_batch <- as.data.frame(current_time_pred_batch)


final_pred_data  <-cbind( model_data$Feed , model_data$Remaining_Rec  ,  feed_pred_batch , current_time_pred_batch)
colnames(final_pred_data)[1] <-  "Feed"
colnames(final_pred_data)[2] <-  "Remaining_Rec"

drops <- c("Feed1 Ingestion End time" ,"Current_Time 00:00:00")
final_pred_data <- final_pred_data[ , !(names(final_pred_data) %in% drops)]



y_test <-  final_test_data$`Time.Taken.to.Complete.in.minutes`


# load the model
linear_test <- readRDS("D:/model/linear.rds")
#class(super_model)
print(linear_test)
# make a predictions on "new data" using the final model
final_predictions <- predict(linear_test , final_pred_data )

final_predictions <-  as.data.frame(final_predictions)

output  <-  cbind(model_data , final_predictions )


write.csv(output , file = "D:/Users/400221371/Desktop/preicted_output.csv" , row.names = F )

# Compare 

data  <-   read.csv("D:/Users/400221371/Desktop/test_data_full.csv")
compare_time <- cbind(data , final_predictions)

write.csv(compare_time , file = "D:/Users/400221371/Desktop/compare_time.csv" , row.names = F )
