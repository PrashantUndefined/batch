#  install.packages("readxl")
# install.packages("caret")
# install.packages("purr")
# install.packages("tidyversev")
# install.packages("dplyr")
# install.packages("randomForest")
# install.packages("devtools")
# install.packages("utf8")
#install.packages("dummies")  To create a dummy variables for the Feed  Column
#install.packages("caTools")
#install.packages("ggplot")
#install.packages("gtools")


predict_data <-  function( prediction_file_path , saved_model_path , predicted_output_file_path)
                           
   {

library(gtools)  
library(ggplot2)
library(caTools)
library(dummies)
library(utf8)
library(devtools)
library(tidyverse)
library(dplyr)
library(randomForest)
library(readxl)
library(caret)


read_test_data <-  read.csv( prediction_file_path , header = T)

pred_data <-  read_test_data
colnames(pred_data)[2] <-  "Current_Time"
colnames(pred_data)[3] <-  "Remaining_Rec"


pred_data$Current_Time  <-  substr(pred_data$Current_Time , 11, 19)

pred_data$Remaining_Rec <-  as.numeric(gsub("k" , replacement = "000" , pred_data$Remaining_Rec , ignore.case = T))

# One Hot Encodeing 

#model_train_data <- cbind( pred_data)

feed_pred_batch <-  dummy(pred_data$Feed)
feed_pred_batch <- as.data.frame(feed_pred_batch)

current_time_pred_batch <-  dummy(pred_data$Current_Time )
current_time_pred_batch <- as.data.frame(current_time_pred_batch)

colnames(final_pred_data)
final_pred_data  <- cbind( Remaining_Rec=pred_data$Remaining_Rec  ,  feed_pred_batch , current_time_pred_batch)


drops <- c("Feed1Cal" ,"Current_Time 00:00:00" )
final_pred_data <- final_pred_data[ , !(names(final_pred_data) %in% drops)]



# load the model
linear_test <- readRDS(saved_model_path)
summary(linear_test)

# make a predictions on "new data" using the final model
                    
final_predictions <- predict(linear_test , final_pred_data )
                          
                      
final_predictions <-  as.data.frame(final_predictions)
                          
output  <-  cbind(pred_data , final_predictions )
                      
write.csv(output , file = predicted_output_file_path , row.names = F )
                          
}

predict_data("D:/Users/400221371/Desktop/test_data_feed.csv"  , "D:/model/linear_test.rds" ,"D:/Users/400221371/Desktop/predicted_output.csv")
